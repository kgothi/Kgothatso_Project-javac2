package cal_app;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;


public class Calculator extends JFrame implements ActionListener{
	
	private static final long serialVersionUID = -5840021137900942567L;
	static JFrame frame;
	static JTextField textField;
	static String first;

	String second;

	String operator;
	
	Calculator() {
		first = second = operator = "";
		
	}
	
	@SuppressWarnings("deprecation")
	public static void main(String[] arg) throws Exception { 
		
		frame = new JFrame("cal");
		UIManager.setLookAndFeel(UIManager.getLookAndFeel());
		Calculator calculator = new  Calculator();
		textField = new JTextField(16);
		textField.setEditable(false);
		
		JButton btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btnAdd, btnSub, btnDiv, btnMul, btnDot, btnClr, btnEq;
		
		btn0 = new JButton("0");
		btn1 = new JButton("1");
		btn2 = new JButton("2");
		btn3 = new JButton("3");
		btn4 = new JButton("4");
		btn5 = new JButton("5");
		btn6 = new JButton("6");
		btn7 = new JButton("7");
		btn8 = new JButton("8");
		btn9 = new JButton("9");
		btnEq = new JButton("=");
		btnAdd = new JButton("Add");
		btnSub = new JButton("Sub");
		btnDiv = new JButton("Div");
		btnMul = new JButton("Mul");
		btnClr = new JButton("Clr");
		
		btnDot = new JButton("Dot");
		
		btnMul.addActionListener(calculator);
		btnDiv.addActionListener(calculator);
		btnSub.addActionListener(calculator);
		btnAdd.addActionListener(calculator);
		btn9.addActionListener(calculator);
		btn8.addActionListener(calculator);
		btn7.addActionListener(calculator);
		btn6.addActionListener(calculator);
		btn5.addActionListener(calculator);
		btn4.addActionListener(calculator);
		btn3.addActionListener(calculator);
		btn2.addActionListener(calculator);
		btn1.addActionListener(calculator);
		btn0.addActionListener(calculator);
		btnDot.addActionListener(calculator);
		btnClr.addActionListener(calculator);
		btnEq.addActionListener(calculator);
		
		JPanel panel = new JPanel();
		panel.add(textField);
		panel.add(btn7);
		panel.add(btn8);
		panel.add(btn9);
		panel.add(btnDiv);
		panel.add(btn4);
		panel.add(btn5);
		panel.add(btn6);
		panel.add(btnMul);
		panel.add(btn1);
		panel.add(btn2);
		panel.add(btn3);
		panel.add(btnSub);
		panel.add(btnDot);
		panel.add(btnClr);
		panel.add(btn0);
		panel.add(btnAdd);
		panel.add(btnEq);
		panel.add(textField);
		panel.add(textField);
		
		panel.setBackground(java.awt.Color.GREEN);
		
		frame.add(panel);
		frame.setSize(200, 220);
		frame.show();
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String action = e .getActionCommand();
		if ((action.charAt(0) >= '0' && action.charAt(0) <='9') || action.charAt(0) == '.') {
			if(action.equals(".") && first.contains(".")) {
			
		}
	else if (!operator.contentEquals("."))
			second = second + action;
		else
			first = first + action;
		
		}
		
	}

	}
	



